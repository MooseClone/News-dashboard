// API utilities for fetching news data

// Function to fetch news from various sources
export async function fetchNews(category: string) {
  try {
    // Using free News API for demonstration
    // For development/demo purposes, return mock data
    return getMockNewsData(category);
  } catch (error) {
    console.error(`Error fetching ${category} news:`, error);
    return getMockNewsData(category);
  }
}

// Function to fetch crypto news
export async function fetchCryptoNews() {
  try {
    // In a real implementation, we would use a crypto-specific API
    return getMockNewsData('crypto');
  } catch (error) {
    console.error('Error fetching crypto news:', error);
    return getMockNewsData('crypto');
  }
}

// Function to fetch AI and breakthrough news
export async function fetchAINews() {
  try {
    // In a real implementation, we would use a specific API or search terms
    return getMockNewsData('ai');
  } catch (error) {
    console.error('Error fetching AI news:', error);
    return getMockNewsData('ai');
  }
}

// Function to fetch Powell speeches and Fed news
export async function fetchFedNews() {
  try {
    // In a real implementation, we would use a specific API for Fed news
    return getMockNewsData('powell');
  } catch (error) {
    console.error('Error fetching Fed news:', error);
    return getMockNewsData('powell');
  }
}

// Function to fetch stock market data
export async function fetchStockData() {
  try {
    // In a real implementation, we would use Yahoo Finance API
    return getMockStockData();
  } catch (error) {
    console.error('Error fetching stock data:', error);
    return getMockStockData();
  }
}

// Mock data for development purposes
function getMockNewsData(category: string) {
  const currentDate = new Date().toISOString().split('T')[0];
  
  const mockData: Record<string, any[]> = {
    technology: [
      {
        id: 'tech1',
        title: 'New AI Breakthrough Enables Real-Time Language Translation',
        description: 'Researchers have developed a new AI model that can translate languages in real-time with near-human accuracy.',
        source: 'TechCrunch',
        url: 'https://techcrunch.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=AI+Translation'
      },
      {
        id: 'tech2',
        title: 'Apple Announces Next-Generation M3 Pro Chips',
        description: 'Apple has unveiled its latest M3 Pro processors with significant performance improvements over previous generations.',
        source: 'The Verge',
        url: 'https://theverge.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Apple+M3+Chip'
      },
      {
        id: 'tech3',
        title: 'Quantum Computing Milestone: 1000-Qubit Processor Developed',
        description: 'Scientists have created a 1000-qubit quantum processor, marking a significant step toward practical quantum computing.',
        source: 'Wired',
        url: 'https://wired.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Quantum+Computing'
      }
    ],
    business: [
      {
        id: 'biz1',
        title: 'Global Supply Chain Issues Easing, Report Finds',
        description: 'A new report indicates that global supply chain disruptions are finally easing after years of pandemic-related challenges.',
        source: 'Bloomberg',
        url: 'https://bloomberg.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Supply+Chain'
      },
      {
        id: 'biz2',
        title: 'Major Merger: Tech Giant Acquires AI Startup for $5 Billion',
        description: 'In one of the largest acquisitions this year, a leading tech company has purchased an AI startup for $5 billion.',
        source: 'Financial Times',
        url: 'https://ft.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Tech+Merger'
      },
      {
        id: 'biz3',
        title: 'Retail Sales Surge 5% in Q2, Exceeding Expectations',
        description: 'Consumer spending has increased significantly in the second quarter, suggesting economic resilience despite inflation concerns.',
        source: 'CNBC',
        url: 'https://cnbc.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Retail+Sales'
      }
    ],
    finance: [
      {
        id: 'fin1',
        title: 'Fed Signals Potential Rate Cut in September Meeting',
        description: 'Federal Reserve officials have hinted at a possible interest rate reduction at their upcoming September meeting.',
        source: 'Wall Street Journal',
        url: 'https://wsj.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Fed+Rate+Cut'
      },
      {
        id: 'fin2',
        title: 'Inflation Drops to 2.8%, Lowest Level in Three Years',
        description: 'The latest CPI data shows inflation has decreased to 2.8%, approaching the Federal Reserve\'s target rate.',
        source: 'Reuters',
        url: 'https://reuters.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Inflation+Data'
      },
      {
        id: 'fin3',
        title: 'Banking Sector Reports Strong Q2 Earnings',
        description: 'Major banks have reported better-than-expected earnings for Q2, with loan growth and trading revenue driving results.',
        source: 'Bloomberg',
        url: 'https://bloomberg.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Bank+Earnings'
      }
    ],
    crypto: [
      {
        id: 'crypto1',
        title: 'Bitcoin Surpasses $80,000 for First Time',
        description: 'Bitcoin has reached a new all-time high, breaking the $80,000 barrier amid increased institutional adoption.',
        source: 'CoinDesk',
        url: 'https://coindesk.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Bitcoin+Record'
      },
      {
        id: 'crypto2',
        title: 'Ethereum Completes Major Network Upgrade',
        description: 'Ethereum has successfully implemented its latest network upgrade, improving scalability and reducing transaction fees.',
        source: 'Decrypt',
        url: 'https://decrypt.co',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Ethereum+Upgrade'
      },
      {
        id: 'crypto3',
        title: 'Central Banks Accelerate CBDC Development',
        description: 'Several major central banks have announced plans to accelerate their central bank digital currency projects.',
        source: 'The Block',
        url: 'https://theblock.co',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=CBDC+Development'
      }
    ],
    ai: [
      {
        id: 'ai1',
        title: 'AI Model Achieves Human-Level Performance in Medical Diagnostics',
        description: 'A new AI system has demonstrated accuracy matching or exceeding human doctors in diagnosing multiple conditions.',
        source: 'MIT Technology Review',
        url: 'https://technologyreview.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=AI+Medical'
      },
      {
        id: 'ai2',
        title: 'Breakthrough: AI System Generates Novel Pharmaceutical Compounds',
        description: 'Scientists have developed an AI that can design new pharmaceutical compounds with specific properties, accelerating drug discovery.',
        source: 'Nature',
        url: 'https://nature.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=AI+Pharma'
      },
      {
        id: 'ai3',
        title: 'AI Ethics Board Proposes New Regulatory Framework',
        description: 'An international AI ethics committee has proposed a comprehensive framework for regulating advanced AI systems.',
        source: 'Wired',
        url: 'https://wired.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=AI+Ethics'
      }
    ],
    global: [
      {
        id: 'global1',
        title: 'Climate Summit Concludes with New Emissions Targets',
        description: 'World leaders have agreed to more ambitious emissions reduction targets at the latest international climate summit.',
        source: 'BBC',
        url: 'https://bbc.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Climate+Summit'
      },
      {
        id: 'global2',
        title: 'Trade Agreement Reached Between Major Economies',
        description: 'Several of the world\'s largest economies have finalized a new trade agreement aimed at reducing tariffs and trade barriers.',
        source: 'Reuters',
        url: 'https://reuters.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Trade+Agreement'
      },
      {
        id: 'global3',
        title: 'Space Collaboration: International Mission to Mars Announced',
        description: 'Multiple countries have joined forces to announce a collaborative mission to Mars, scheduled for launch in 2028.',
        source: 'CNN',
        url: 'https://cnn.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Mars+Mission'
      }
    ],
    powell: [
      {
        id: 'powell1',
        title: 'Powell: Economy Showing Resilience Despite Challenges',
        description: 'In his latest speech, Fed Chair Jerome Powell noted that the U.S. economy continues to show resilience despite global uncertainties.',
        source: 'Federal Reserve',
        url: 'https://federalreserve.gov',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Powell+Speech'
      },
      {
        id: 'powell2',
        title: 'Fed Chair Signals Shift in Monetary Policy Approach',
        description: 'Jerome Powell has indicated a potential shift in the Federal Reserve\'s approach to monetary policy in response to changing economic conditions.',
        source: 'CNBC',
        url: 'https://cnbc.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Fed+Policy'
      },
      {
        id: 'powell3',
        title: 'Powell Addresses Banking Stability in Congressional Testimony',
        description: 'Federal Reserve Chair Jerome Powell testified before Congress on the stability of the banking system and current monetary policy.',
        source: 'Wall Street Journal',
        url: 'https://wsj.com',
        publishedAt: currentDate,
        imageUrl: 'https://placehold.co/600x400?text=Powell+Testimony'
      }
    ]
  };
  
  return mockData[category] || mockData.technology;
}

// Mock stock data for development purposes
function getMockStockData() {
  return [
    { symbol: 'AAPL', name: 'Apple Inc.', price: 198.45, change: +2.34, percentChange: +1.19 },
    { symbol: 'MSFT', name: 'Microsoft Corp.', price: 415.32, change: +5.67, percentChange: +1.38 },
    { symbol: 'GOOGL', name: 'Alphabet Inc.', price: 175.89, change: -1.23, percentChange: -0.69 },
    { symbol: 'AMZN', name: 'Amazon.com Inc.', price: 182.56, change: +3.45, percentChange: +1.93 },
    { symbol: 'NVDA', name: 'NVIDIA Corp.', price: 950.12, change: +15.67, percentChange: +1.68 },
    { symbol: 'TSLA', name: 'Tesla Inc.', price: 245.78, change: -5.43, percentChange: -2.16 },
    { symbol: 'META', name: 'Meta Platforms Inc.', price: 485.23, change: +8.76, percentChange: +1.84 },
    { symbol: 'BTC-USD', name: 'Bitcoin USD', price: 82345.67, change: +1234.56, percentChange: +1.52 },
    { symbol: 'ETH-USD', name: 'Ethereum USD', price: 4567.89, change: +123.45, percentChange: +2.78 }
  ];
}
