import { useState, useEffect } from 'react';
import NewsSection from './components/NewsSection';
import StockTicker from './components/StockTicker';
import { fetchStockData, fetchCryptoNews, fetchAINews, fetchFedNews } from './lib/api';

function App() {
  const [stocks, setStocks] = useState<any[]>([]);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [darkMode, setDarkMode] = useState<boolean>(false);

  useEffect(() => {
    // Set up dark mode based on user preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }

    // Update current time
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }));
    };

    updateTime();
    const timeInterval = setInterval(updateTime, 60000);

    // Fetch stock data
    const getStocks = async () => {
      const stockData = await fetchStockData();
      setStocks(stockData);
    };
    
    getStocks();
    const stockInterval = setInterval(getStocks, 300000); // Update every 5 minutes

    return () => {
      clearInterval(timeInterval);
      clearInterval(stockInterval);
    };
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gray-900' : 'bg-gray-100'}`}>
      <header className="bg-white dark:bg-gray-800 shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-blue-600 dark:text-blue-400">Daily News Dashboard</h1>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-300">{currentTime}</span>
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
                aria-label="Toggle dark mode"
              >
                {darkMode ? '🌞' : '🌙'}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="bg-blue-600 dark:bg-blue-800 text-white py-2">
        <div className="container mx-auto px-4">
          <StockTicker stocks={stocks} />
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-8">
          <NewsSection title="Global Headlines" category="global" />
          <NewsSection title="Technology News" category="technology" />
          <NewsSection title="Business & Finance" category="business" />
          <NewsSection title="Cryptocurrency" category="crypto" fetchFunction={fetchCryptoNews} />
          <NewsSection title="AI & Breakthroughs" category="ai" fetchFunction={fetchAINews} />
          <NewsSection title="Fed & Powell Speeches" category="powell" fetchFunction={fetchFedNews} />
        </div>
      </main>

      <footer className="bg-white dark:bg-gray-800 shadow-inner py-6">
        <div className="container mx-auto px-4">
          <div className="text-center text-gray-600 dark:text-gray-300">
            <p>Daily News Dashboard - Last updated: {currentTime}</p>
            <p className="text-sm mt-2">
              This dashboard provides the latest news on technology, business, finance, crypto, AI, breakthroughs, global headlines, and Powell speeches.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
