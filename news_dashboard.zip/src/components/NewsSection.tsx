import { useState, useEffect } from 'react';
import NewsCard from './NewsCard';
import SectionHeader from './SectionHeader';
import { fetchNews } from '../lib/api';

interface NewsSectionProps {
  title: string;
  category: string;
  fetchFunction?: () => Promise<any[]>;
}

const NewsSection: React.FC<NewsSectionProps> = ({ 
  title, 
  category,
  fetchFunction 
}) => {
  const [news, setNews] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const getNews = async () => {
      try {
        setLoading(true);
        let newsData;
        
        if (fetchFunction) {
          newsData = await fetchFunction();
        } else {
          newsData = await fetchNews(category);
        }
        
        setNews(newsData);
        setError(null);
      } catch (err) {
        setError('Failed to load news');
        console.error(`Error loading ${category} news:`, err);
      } finally {
        setLoading(false);
      }
    };

    getNews();
  }, [category, fetchFunction]);

  return (
    <section className="mb-8">
      <SectionHeader title={title} />
      
      {loading ? (
        <div className="flex justify-center items-center h-48">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {news.map((item) => (
            <NewsCard
              key={item.id}
              title={item.title}
              description={item.description}
              source={item.source}
              url={item.url}
              publishedAt={item.publishedAt}
              imageUrl={item.imageUrl}
            />
          ))}
        </div>
      )}
    </section>
  );
};

export default NewsSection;
