import React from 'react';

interface StockTickerProps {
  stocks: {
    symbol: string;
    name: string;
    price: number;
    change: number;
    percentChange: number;
  }[];
}

const StockTicker: React.FC<StockTickerProps> = ({ stocks }) => {
  return (
    <div className="overflow-x-auto">
      <div className="inline-flex animate-marquee whitespace-nowrap py-2">
        {stocks.map((stock, index) => (
          <div 
            key={stock.symbol} 
            className="inline-flex items-center mx-4 first:ml-0"
          >
            <div className="flex flex-col">
              <div className="flex items-center">
                <span className="font-semibold text-gray-900 dark:text-white mr-2">
                  {stock.symbol}
                </span>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {stock.name}
                </span>
              </div>
              <div className="flex items-center">
                <span className="font-medium mr-2">
                  ${stock.price.toLocaleString()}
                </span>
                <span 
                  className={`text-sm ${
                    stock.change >= 0 
                      ? 'text-green-600 dark:text-green-400' 
                      : 'text-red-600 dark:text-red-400'
                  }`}
                >
                  {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.percentChange >= 0 ? '+' : ''}{stock.percentChange.toFixed(2)}%)
                </span>
              </div>
            </div>
            {index < stocks.length - 1 && (
              <div className="mx-4 h-8 border-r border-gray-200 dark:border-gray-700"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default StockTicker;
